export enum USER_ROLE{
    GENERAL_USER = "general_user",
    ADMIN = "admin",
    SUPER_ADMIN = "super_admin"
}