import React from 'react';

const BlogCard = () => {
  return (
    <div>
      
    </div>
  );
};

export default BlogCard;