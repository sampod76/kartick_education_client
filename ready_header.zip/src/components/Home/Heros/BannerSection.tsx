import React from 'react';

const BannerSection = () => {
    return (
        <div>
            <h2>This is banner section </h2>
        </div>
    );
};

export default BannerSection;