import React from 'react';

const LatestNews = () => {
  return (
    <div>
      
    </div>
  );
};

export default LatestNews;