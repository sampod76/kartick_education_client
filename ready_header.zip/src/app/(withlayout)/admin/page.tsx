const AdminPage = () => {
  return (
    <div>
      <h1>Welcome To Admin Profile</h1>
    </div>
  );
};

export default AdminPage;
