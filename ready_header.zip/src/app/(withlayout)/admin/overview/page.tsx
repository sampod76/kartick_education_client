import React from 'react';

const OverviewAdmin = () => {
    return (
        <div>
          <h1>Overview page</h1>  
        </div>
    );
};

export default OverviewAdmin;