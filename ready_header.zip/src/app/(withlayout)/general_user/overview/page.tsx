import React from 'react';

const GeneralUserOverview = () => {
    return (
        <div>
          <h1>Overview page</h1>  
        </div>
    );
};

export default GeneralUserOverview;