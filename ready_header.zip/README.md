
 ## কেন জানি আমার সার্ভারে শুধু cors error  দেয়  যার কারণে কষ্ট করে একটা CORS এক্সটেনশন রান করে নিতে হয়

## এবং আমাকে আমার Deploy করার কোন ইমেজে শো করে না | লোকালি সব ঠিকঠাক মত চলে

front end = https://assernment9.salontrainingpro.app/
backend = https://school-api.salontrainingpro.app

## front end github : 
https://github.com/sampod76/l2-assernment-9-Frontend-computer-repair-service.git

## backend github : 
https://github.com/sampod76/l2-assernment-9-backend-computer-repair-service.git

//
super_admin :sampodnath@gmail.com
password : 112233
//
admin:sampodnath1122@gmail.com
password : 11223344

//
customer:example@gmail.com
password : 11223344
