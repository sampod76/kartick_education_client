import React from 'react'

export default function CategoryButtonSKeletton() {
  return (
   <div className="flex justify-start items-center ">
     <div className=' w-8 h-6 animate-pulse bg-slate-400  py-3 px-7 rounded-tl-[20px] rounded-br-[20px]'>
</div>
     <div className=' w-8 h-6 animate-pulse bg-slate-400  py-3 px-7 rounded-tl-[20px] rounded-br-[20px]'>
</div>
     <div className=' w-8 h-6 animate-pulse bg-slate-400  py-3 px-7 rounded-tl-[20px] rounded-br-[20px]'>
</div>
   </div>
  )
}
