import { Spin } from "antd";
import React from "react";

const ButtonLoading = () => {
  return (
    <>
      <Spin />
    </>
  );
};

export default ButtonLoading;
