import { Skeleton } from 'antd'
import React from 'react'


export default function LoaderNextImage() {
  return (
    // <div> <Skeleton.Image active={true} /></div>
    '../../../assets/no-images.jpg'
  )
}

   