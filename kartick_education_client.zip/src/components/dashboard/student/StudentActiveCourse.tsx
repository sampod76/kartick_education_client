
import React from 'react'
// import Courses from "../"

export default function StudentActiveCourse() {
  return (
    <div>

        {/* <Courses query={{}} /> */}
    </div>
  )
}
