import Quizes from "@/components/Quiz/Quizes";
import UMBreadCrumb from "@/components/ui/UMBreadCrumb";
import React from "react";

export default function QuizPage() {
  return (
    <div className=" bg-slate-100">
      
      <Quizes />
    </div>
  );
}
