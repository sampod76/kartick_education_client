import CreateStudent from "@/components/stepper/CreateStudent";
import React from "react";

export default function SignUpStudent() {
  return (
    <div>
      <CreateStudent />
    </div>
  );
}
