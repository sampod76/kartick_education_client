import React from "react";

const DashboardPage = () => {
  return (
    <div>
      <h1>This is Dashboard Page</h1>
    </div>
  );
};

export default DashboardPage;
