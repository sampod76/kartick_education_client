import React from 'react'

export default function ActiveCourse() {
  return (
    <div>ActiveCourse</div>
  )
}
