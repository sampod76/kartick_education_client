import React from "react";

const SupportAndHelp = () => {
  return (
    <div>
      <h1>Support and help center</h1>
    </div>
  );
};

export default SupportAndHelp;
