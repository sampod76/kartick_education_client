const StudentPage = () => {
  return (
    <div>
      <h1>This page is for student</h1>
    </div>
  );
};

export default StudentPage;
