
import CreateQuizByLesson from '@/components/Quiz/CreateQuizByModule'
import React from 'react'


export default function CreateAdminQuizByLesson() {
  return (
    <div><CreateQuizByLesson/></div>
  )
}
