
import MileStoneList from '@/components/milestone/MilestoneList'
import React from 'react'

export default function AdminMilestonePage() {
  return (
    <div><MileStoneList/></div>
  )
}
