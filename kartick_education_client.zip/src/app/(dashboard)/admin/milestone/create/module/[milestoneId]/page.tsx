
import CreateModuleByMilestone from '@/components/module/CreateModuleByMilestone'
import React from 'react'


export default function CreateAdminModuleByMilestone() {
  return (
    <div><CreateModuleByMilestone/></div>
  )
}
