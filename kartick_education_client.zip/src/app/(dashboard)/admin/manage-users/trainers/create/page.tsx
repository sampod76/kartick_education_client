import CreateTrainer from "@/components/registionfrom/trainer";
import React from "react";

export default function CreateTrainerPage() {
  return (
    <div>
      <CreateTrainer />
    </div>
  );
}
