import CreateSingleQuiz from '@/components/single-auiz/CreateSingleQuiz'
import React from 'react'

export default function CreateAdminSIngleCoursePage() {
  return (

    <div><CreateSingleQuiz/></div>
  )
}

