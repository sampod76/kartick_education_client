
import CreateQuiz from '@/components/Quiz/CreateQuiz'
import React from 'react'

export default function CreateAdminQuizPage() {
  return (
    <div><CreateQuiz/></div>
  )
}
