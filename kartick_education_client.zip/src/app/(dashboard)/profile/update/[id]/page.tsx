import React from 'react';

const ProfileUpdate = ({params}:{params:string}) => {
    return (
        <div>
            
        </div>
    );
};

export default ProfileUpdate;