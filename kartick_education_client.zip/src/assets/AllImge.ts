import noimage from "./noImge.jpg";

export const AllImage = {
  noimage,
};
