import notFoundImage from '../assets/no-images.jpg'
export const NO_IMAGE = notFoundImage