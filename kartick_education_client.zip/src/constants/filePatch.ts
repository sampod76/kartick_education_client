import noimage from '../assets/no-images.jpg'
export const NO_IMAGE = noimage