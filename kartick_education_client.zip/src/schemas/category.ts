export type ICategory = {
    title: string;
    img?: string 
    status?: string;
  };