## কেন জানি আমার সার্ভারে শুধু cors error দেয় যার কারণে কষ্ট করে একটা CORS এক্সটেনশন রান করে নিতে হয়

## এবং আমাকে আমার Deploy করার কোন ইমেজে শো করে না | লোকালি সব ঠিকঠাক মত চলে

front end = https://assernment9.salontrainingpro.app/
backend = https://school-api.salontrainingpro.app

## front end github :

https://github.com/sampod76/l2-assernment-9-Frontend-computer-repair-service.git

## backend github :

https://github.com/sampod76/l2-assernment-9-backend-computer-repair-service.git

//
super_admin :sampodnath@gmail.com
password : 112233
//
admin:sampodnath1122@gmail.com
password : 11223344

//
customer:example@gmail.com
password : 11223344

# kartick_education_client

### Update of 20 December

- 1. include video demo in create course,Quiz, single quiz

```json
 "demo_video": {
    "vimeo": "https://vimeo.com/848962637?share=copy",
    "platform": "vimeo"
  }
```

- 2.  Redux for quiz and Single Quiz --done
- 3.  Created 2 reusable UI and hook --done
- 4.  Done with DemoVideoUI reusable UI\*\* --done

### Update 21 December 2024

- 1. Single Quiz with answer options -- Not Fixed
- 2. Milestone showing
- 3. Table Responsive
- 4. Create UI
- 5. Reusable Selection Form --done

#### up 22 December 2024

- 1. Form responsive - OK
  - Category create and update form
  - Course create and update form
  -
- 2. Table sorting include - OK

  - status condition
  -

- 3. details page of category, course,milestone, module,lesson, quiz
- 4.

###

- 1. navbar user icon
- 2. navItems change
- 3. HomePage

### 25 December 2023

- 1.  User(Student, Admin,trainer, seller) view , delete in dashboard
- 2.  Nav item

### 1 January 2024

1. category in courses list in dashboard;
2. course action with add new milestone .
3. details course with skelton in dashboard.
4. 


### 3 January

1. registration from for student
2. update in dashboard
3. 


## 9 January 

1. Answer input fixed
2. collapse of lesson 
3. dashboard of role based
4. 