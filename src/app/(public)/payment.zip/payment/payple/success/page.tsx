import React from 'react'

export default function Palyled() {
  return (
    <div>Success fully stripe payment</div>
  )
}
