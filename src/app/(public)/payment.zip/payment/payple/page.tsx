import React from 'react'

export default function Palese() {
  return (
    <div>Palese</div>
  )
}
