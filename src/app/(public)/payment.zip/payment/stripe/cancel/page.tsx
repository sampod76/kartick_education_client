import React from 'react'

export default function StripeCancel() {
  return (
    <div>Cancel fully stripe payment</div>
  )
}
