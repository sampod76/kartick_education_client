import React from 'react'

export default function StripeSuccess() {
  return (
    <div>Success fully stripe payment</div>
  )
}
