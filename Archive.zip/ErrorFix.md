<!-- http://localhost:3000/admin/course/edit/6599a73fd327428ade1326b7 -->

demo video edit now works
