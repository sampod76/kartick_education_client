import React from "react";
import SubscriptionSelect from "./SubscriptionSelect";

export default function Subscription() {
  return (
    <div className="min-h-screen">
      <SubscriptionSelect />
    </div>
  );
}
