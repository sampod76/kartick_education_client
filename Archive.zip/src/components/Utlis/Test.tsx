import React from 'react'

export default function Test({ open, setOpen }:any) {
    console.log(open);
  return (
    <div>Test</div>
  )
}
