import { Skeleton } from "antd";
import React from "react";

export default function LoaderNextImage() {
  return (
    // <div> <Skeleton.Image active={true} /></div>
    "https://media.giphy.com/media/9MImS9neQuoRa3D19h/giphy.gif"
  );
}
