import React from 'react'

export default function StripeSuccessssss() {
  return (
    <div>Success fully stripe payment</div>
  )
}
