import OrderSummery from "@/components/dashboard/seller/OrderSummery";
import React from "react";

export default function SellerOrderSummeryPage() {
  return (
    <div>
      <OrderSummery />
    </div>
  );
}
