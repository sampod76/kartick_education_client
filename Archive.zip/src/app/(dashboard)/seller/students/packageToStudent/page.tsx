import React from 'react'

export default function PackageToStudentS() {
  return (
    <div>page</div>
  )
}
