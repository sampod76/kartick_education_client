import React from 'react';

const GeneralUserOverview = () => {
    return (
        <div>
          <h1 className="text-base font-normal">Overview page</h1>  
        </div>
    );
};

export default GeneralUserOverview;