import React from 'react'

export default function Assignment() {
  return (
    <div className='flex justify-center items-center '>Upcoming...</div>
  )
}
