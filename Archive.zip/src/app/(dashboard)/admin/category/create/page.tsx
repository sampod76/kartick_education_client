import CreateCategory from '@/components/category/CreateCategory'
import React from 'react'

export default function CategoryAdminCreatePage() {
  return (
    <div>
      <CreateCategory/>
    </div>
  )
}
