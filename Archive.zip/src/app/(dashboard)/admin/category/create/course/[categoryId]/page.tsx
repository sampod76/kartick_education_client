import CreateCourseByCategory from '@/components/Course/CreateCourseByCategory'
import React from 'react'

export default function CreateAdminCourseByCategoryPage() {
  return (
    <div><CreateCourseByCategory/></div>
  )
}

