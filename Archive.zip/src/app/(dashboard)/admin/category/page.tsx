import CategoryList from '@/components/category/CategoryList'
import React from 'react'

export default function AdminCategoryListPage() {
  return (
    <div><CategoryList/></div>
  )
}
