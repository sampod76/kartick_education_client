import CourseList from '@/components/Course/CourseList'
import React from 'react'

export default function AdminCourseListPage() {
  return (
    <div><CourseList/></div>
  )
}
