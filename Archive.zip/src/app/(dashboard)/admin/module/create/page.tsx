
import CreateModule from '@/components/module/create/CreateModule'
import React from 'react'


export default function CreateAdminModulePage() {
  return (

    <div><CreateModule /></div>
  )
}

