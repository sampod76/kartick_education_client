import ModuleDashList from '@/components/module/ModuleDashList'
import React from 'react'

export default function ModuleAdminListPage() {
  return (
    <div><ModuleDashList/></div>
  )
}
