import PurchasePackageList from "@/components/purchase-course/PurchaseCourseList";


export default function PurchasePackageListPage() {
    return (<div>
        <PurchasePackageList />
    </div>)
}
