import React from "react";

export default function GlossaryEdit() {
  return <div>GlossaryEdit</div>;
}
