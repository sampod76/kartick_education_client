import GlossaryCreate from '@/components/Glossary/GlossaryCreate'
import React from 'react'

export default function GlossaryCreatePage() {
  return (
    <div>
      <GlossaryCreate/>
    </div>
  )
}
