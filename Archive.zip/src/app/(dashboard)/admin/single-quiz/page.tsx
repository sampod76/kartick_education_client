import SingleQuizList from '@/components/single-auiz/SingleQuizList'
import React from 'react'

export default function SIngleQuizAdminList() {
  return (
    <div><SingleQuizList/></div>
  )
}
