
import CreateSkillsPlan from '@/components/features/skills-plan/create/CreateSkillsPlan'
import React from 'react'

export default function CreateSkillsPlanPage() {
    return (
        <div><CreateSkillsPlan /></div>
    )
}
