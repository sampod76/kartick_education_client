import CreateAdvanceClass from '@/components/features/advance-class/create/CreateAdvanceClass'
import React from 'react'

export default function CreateAdvanceClassPage() {
    return (
        <div><CreateAdvanceClass /></div>
    )
}
