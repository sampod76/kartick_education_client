import AdvanceClassList from '@/components/features/advance-class/AdvanceClassDashList.tsx'
import React from 'react'

export default function AdvanceClassPage() {
  return (
    <div><AdvanceClassList /></div>
  )
}
