
import CreateLesson from '@/components/lesson/CreateLesson'
import React from 'react'


export default function CreateAdminLessonPage() {
  return (
    <div><CreateLesson/></div>
  )
}
