import PackageDashList from '@/components/package/PackageDashList'
import React from 'react'

export default function PackageList() {
  return (
    <div><PackageDashList/></div>
  )
}
