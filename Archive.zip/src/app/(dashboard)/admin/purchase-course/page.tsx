import PurchaseCourseList from "@/components/purchase-course/PurchaseCourseList";



export default function PurchaseCourseListPage() {
    return (<div>
        <PurchaseCourseList />
    </div>)
}
