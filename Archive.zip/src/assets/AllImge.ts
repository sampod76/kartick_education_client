import notFoundImage from "./noImge.jpg";
import siteLogo from "./Logo/Rectangle 1.png";
import profileAvater from "./profile.jpg";
import subFamily from "./subscription/v2Family.jpg";
import subAdmin from "./subscription/v2Custom.png";
import subTeacher from "./subscription/v2Scholl.png";

export const AllImage = {
  notFoundImage,
  siteLogo,
  profileAvater,
  subscription: {
    subTeacher,
    subAdmin,
    subFamily,
  },
};
